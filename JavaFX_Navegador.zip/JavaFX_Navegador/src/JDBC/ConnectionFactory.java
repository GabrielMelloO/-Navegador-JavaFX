package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class ConnectionFactory
{
    public static Connection getConnection()
    {
        Connection conexao_BD = null;
        
        try{
            conexao_BD = DriverManager.getConnection("jdbc:postgresql://localhost/BD_JavaFX_Navegador", "postgres", "aluno");
        }catch(SQLException ex){
            System.out.println("Azul " + ex.getMessage());
        }
        
        return conexao_BD;
    }
}
