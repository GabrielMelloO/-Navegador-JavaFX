package Models;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Favoritos
{
    private String Nome;
    private String Link;
    
    public Favoritos(){}

    //GET e SET - Nome
    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    //GET e SET - Link
    public String getLink() {
        return Link;
    }

    public void setLink(String Link) {
        this.Link = Link;
    }
}
