package Dao;

import JDBC.ConnectionFactory;
import Models.Favoritos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Dao_Favoritos
{
    private static Connection conexao_BD;
    
    public Dao_Favoritos()
    {
        Dao_Favoritos.conexao_BD = ConnectionFactory.getConnection();
    }
    
    public static void Coloca_Favoritos(Favoritos favoritos)
    {
        String sql = "INSERT INTO Favoritos" + "(Nome, Link)"
                + "VALUES(?,?);";
        
        try{
            
            PreparedStatement stat = conexao_BD.prepareStatement(sql);
            
            stat.setString(1, favoritos.getNome());
            stat.setString(2, favoritos.getLink());     
            stat.execute();
            stat.close();
            
        }catch(SQLException ex){
            System.out.println("Verde " + ex.getMessage());
        }
    }
}
