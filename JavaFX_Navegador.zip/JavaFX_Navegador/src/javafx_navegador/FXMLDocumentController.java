package javafx_navegador;


import Models.Favoritos;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.web.WebView;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXMLDocumentController implements Initializable
{
    
    @FXML private WebView webView = new WebView();
    
    @FXML private TextField Barra_Pesquisar;
    
    @FXML private Button Pesquisar;
    
    @FXML private MenuBar Menu;
    
    @FXML private Menu Opcoes;
    
    @FXML private MenuItem Adicionar_Favoritos_A;
    
    @FXML
    private void Pesquisar(ActionEvent event)
    {
        webView.getEngine().load(Barra_Pesquisar.getText());  
    }
    
    @FXML
    private void Adicionar_Favoritos(ActionEvent event)
    {
        try{
            Favoritos fav = new Favoritos();

            fav.setNome("Azul");
            fav.setLink(Barra_Pesquisar.getText());

            Dao.Dao_Favoritos.Coloca_Favoritos(fav);
        
        }catch(Exception ex){
            System.out.print("Amarelo");
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        webView.getEngine().load("http://www.google.com.br");
    }       
}
